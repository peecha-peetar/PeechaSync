"""متن‌های راهنمای کاربر — یک منبع برای تب‌های مختلف."""

from __future__ import annotations

from sync_app.core.reconciliation_service import (
    ENTITY_ATTRIBUTES,
    ENTITY_CATEGORIES,
    ENTITY_PRODUCTS,
    ENTITY_VARIATIONS,
)

# تفاوت مهم که کاربران گیج می‌شوند
_GUIDE_RECON_VS_SYNC = """
<p><b>💡 تطبیق با همگام‌سازی فرق دارد</b><br>
<b>تطبیق</b> فقط می‌گوید «کدام کالای ERP همان کالای سایت است» و در فایل نگاشت ذخیره می‌شود.<br>
<b>همگام‌سازی</b> (تب محصولات / متغیرها / ویژگی‌ها) قیمت، موجودی و ساخت واریانت را واقعاً روی سایت می‌فرستد.<br>
اگر تطبیق زدید ولی همگام نکردید، در سایت چیزی عوض نمی‌شود.</p>
"""

_GUIDE_RECON_STEPS = """
<p><b>🔄 مراحل این تب</b></p>
<ol style="margin-top:4px;margin-bottom:8px;">
<li><b>انتخاب نوع</b> — محصول، متغیر، دسته یا ویژگی (نوار سبز بالا).</li>
<li><b>بارگذاری مقایسه</b> — لیست ERP و Woo را می‌آورد.</li>
<li><b>یافتن پیشنهادها</b> — جفت‌های محتمل بنفش می‌شوند.</li>
<li><b>پذیرش</b> — بررسی نام و کد → آماده ثبت (آبی).</li>
<li><b>ثبت نهایی تطبیق</b> — بعد از بکاپ سایت.</li>
</ol>
"""

_GUIDE_RECON_COLORS = """
<p><b>🎨 رنگ‌ها</b></p>
<ul style="margin-top:4px;margin-bottom:8px;">
<li><b>بنفش</b> — پیشنهاد سیستم</li>
<li><b>آبی</b> — آماده ثبت (هنوز ذخیره نشده)</li>
<li><b>زرد</b> — منتظر جفت</li>
<li><b>سبز</b> — قبلاً ثبت شده</li>
</ul>
"""

RECON_ENTITY_HINTS: dict[str, str] = {
    ENTITY_PRODUCTS: """
<p><b>📦 راهنمای نوع «محصول»</b></p>
<ul style="margin-top:4px;margin-bottom:8px;">
<li>کد والد ERP (مثلاً <b>0301001</b>) را به همان محصول در Woo (مثلاً <b>#2972</b>) وصل کنید.</li>
<li>برای هر کالا <b>یک بار</b> کافی است — پایهٔ همه مراحل بعدی است.</li>
<li>بعد از ثبت: تب <b>ویژگی‌ها</b> → همگام، سپس تب <b>متغیرها</b> → همگام.</li>
<li>اینجا واریانت ساخته <b>نمی‌شود</b>؛ فقط می‌گوید کدام محصول والد همان است.</li>
</ul>
""",
    ENTITY_VARIATIONS: """
<p><b>🎨 راهنمای نوع «متغیر» — مهم</b></p>
<ul style="margin-top:4px;margin-bottom:8px;">
<li><b>ساخت واریانت در سایت اینجا انجام نمی‌شود</b> — در تب «متغیرها» → «همگام‌سازی واریانت‌ها».</li>
<li>اگر در Woo خط «بدون واریانت در سایت» یا «تطبیق والد ثبت شد» می‌بینید: یعنی والد وصل شده ولی واریانت هنوز ساخته نشده — طبیعی است.</li>
<li>نیاز نیست V11، V12، V13 را <b>جدا جدا</b> جفت کنید؛ یک بار والد (کد 0301001 ↔ #2972) کافی است.</li>
<li>پیش‌نیاز: نوع «محصول» ثبت شده + تب «ویژگی‌ها» همگام شده باشد.</li>
<li>بعد از همگام متغیرها، اینجا خطوط واقعی مثل <b>0301001-V11</b> ظاهر می‌شوند.</li>
</ul>
""",
    ENTITY_CATEGORIES: """
<p><b>📂 راهنمای نوع «دسته»</b></p>
<ul style="margin-top:4px;margin-bottom:8px;">
<li>فقط دسته‌هایی را وصل کنید که واقعاً کالای شما در آن‌هاست (مثلاً نرم‌افزار 03).</li>
<li><b>Uncategorized</b> با «خدمات» یا «پارچه» خودکار جفت <b>نمی‌شود</b> — کد و نام یکی نیست.</li>
<li>اگر دسته‌ای در سایت ندارید، می‌توانید رها کنید؛ روی قیمت محصول اثر مستقیم ندارد.</li>
</ul>
""",
    ENTITY_ATTRIBUTES: """
<p><b>🏷️ ویژگی — فقط مشاهده</b></p>
<ul style="margin-top:4px;margin-bottom:8px;">
<li><b>سبز</b> = نام در ERP و سایت یکی است (مثلاً «سطح»).</li>
<li>اتصال دستی، لغو جفت و ثبت فایل <b>اینجا نیست</b>.</li>
<li>ساخت/به‌روزرسانی در Woo → تب <b>«ویژگی‌ها»</b> → همگام‌سازی.</li>
</ul>
""",
}

RECON_HERO_GUIDE_HTML = (
    _GUIDE_RECON_VS_SYNC
    + _GUIDE_RECON_STEPS
    + RECON_ENTITY_HINTS[ENTITY_PRODUCTS]
    + _GUIDE_RECON_COLORS
    + """
<p><b>⚠️ ایمنی</b><br>
قبل از ثبت نهایی بکاپ سایت بگیرید.</p>
<p><b>🔍 نوار وضعیت</b><br>
با تغییر «نوع»، راهنمای بالا برای همان نوع به‌روز می‌شود.</p>
"""
).strip()


def recon_hero_html_for_entity(entity: str, config: dict | None = None) -> str:
    """راهنمای تب تطبیق با نکتهٔ مخصوص نوع انتخاب‌شده."""
    import re

    from sync_app.core.integrations.erp_provider import erp_provider_label

    hint = RECON_ENTITY_HINTS.get(
        str(entity or ENTITY_PRODUCTS).strip(),
        RECON_ENTITY_HINTS[ENTITY_PRODUCTS],
    )
    html = (
        _GUIDE_RECON_VS_SYNC
        + _GUIDE_RECON_STEPS
        + hint
        + _GUIDE_RECON_COLORS
        + "<p><b>⚠️ ایمنی</b><br>قبل از ثبت نهایی بکاپ سایت بگیرید.</p>"
    ).strip()
    return re.sub(r"\bERP\b", erp_provider_label(config), html)


VARIATIONS_TAB_GUIDE_TEXT = (
    "راهنمای این تب: "
    "اینجا واریانت‌ها در Woo ساخته یا به‌روز می‌شوند (قیمت + موجودی). "
    "تب «تطبیق» فقط می‌گوید کدام محصول همان است؛ واریانت نمی‌سازد. "
    "ترتیب: ۱) تطبیق → محصول (مثلاً 0301001 ↔ #2972) "
    "۲) ویژگی‌ها → همگام (برای نرم‌افزار معمولاً فقط «سطح» کافی است، نه «رنگ») "
    "۳) (اگر لازم بود) تطبیق → متغیر برای والد بدون واریانت "
    "۴) همین تب → «همگام‌سازی واریانت‌ها»."
)

VARIATIONS_SYNC_BUTTON_TOOLTIP = (
    "واریانت‌های ERP را در Woo می‌سازد یا قیمت/موجودی را به‌روز می‌کند.\n"
    "پیش‌نیاز: تطبیق محصول + همگام ویژگی‌ها.\n"
    "اگر در تطبیق «بدون واریانت در سایت» دیدید، اول این دکمه را بزنید."
)


def variations_sync_button_tooltip(config: dict | None = None) -> str:
    import re

    from sync_app.core.integrations.erp_provider import erp_provider_label

    return re.sub(r"\bERP\b", erp_provider_label(config), VARIATIONS_SYNC_BUTTON_TOOLTIP)
