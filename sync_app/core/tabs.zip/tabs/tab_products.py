import sys
import os
import json
import re
import shutil
import time
import pyodbc
import urllib.request
import requests
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton,
    QListWidget, QMessageBox, QHBoxLayout, QTextEdit, QListWidgetItem, QToolTip, QSplitter,
    QLineEdit, QCheckBox, QFileDialog, QProgressBar, QToolButton, QDialog, QDialogButtonBox,
    QComboBox, QApplication, QTabWidget
)
from PyQt5.QtCore import Qt, QTimer, QPoint, QEvent, QSize
from PyQt5.QtGui import QColor, QCursor, QFont, QGuiApplication, QPainter, QPixmap
from sync_app.core.log_panel_ui import LogPanelController, VerticalTextButton, LogActionRail
from sync_app.core.rtl_item_delegate import RightAlignedCheckableItemDelegate
from sync_app.core.jalali_log_formatter import format_log_lines_jalali

# 📌 مسیر پکیجی درست برای بارگذاری تنظیمات
from sync_app.core.secure_config_loader import load_secure_config, save_secure_config
from sync_app.core.sync_utils import app_path, clear_filtered_logs, log
from sync_app.core.article_price import resolve_article_price
from sync_app.core.sql_connection_helper import open_sql_connection, format_db_error
from sync_app.core.threading_helper import run_in_thread
from sync_app.core.selection_toggle_bar import attach_selection_toggle
from sync_app.core.responsive_action_bar import build_responsive_action_row
from sync_app.core.compact_icon_action_bar import CompactCaptionButton
from sync_app.core.wc_admin_links import make_wc_admin_open_button
from sync_app.core.tab_action_controller import TabActionController, ActionSpec

# 📌 اجرای مستقیم اسکریپت محصولات
from sync_app.core.scripts import sync_fullproduct
from sync_app.core.sync_job_runner import run_background_sync, cancel_background_sync
from sync_app.core.connectivity_wait import wait_for_connectivity_blocking, is_transient_connectivity_issue
from sync_app.core.connectivity_guard import ensure_connectivity
from sync_app.core.live_site_backup_guard import confirm_live_site_backup
from sync_app.core.product_sync_guard import build_products_sync_preview, ProductSyncPreviewDialog
from sync_app.core.wc_site_profiles import ensure_wc_sites
from sync_app.core.wc_sync_helper import (
    wp_upload_media_ex,
    update_wc_product_images,
    verify_wp_media_credentials,
    should_retry_upload_error,
    is_wp_upload_fatal_error,
    WP_UPLOAD_MAX_ATTEMPTS,
    wc_rest_request,
    build_wcapi,
    apply_network_overrides,
)
from sync_app.core.erp_image_helper import stage_erp_images
from sync_app.core.product_woo_map_helper import load_product_woo_map
from sync_app.core.seo_helper import analyze_product_seo_live, apply_seo_fixes

try:
    from woocommerce import API as WCAPI
except ImportError:
    WCAPI = None


def _guess_mime(filename):
    ext = os.path.splitext(filename.lower())[1]
    return {
        '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
        '.png': 'image/png', '.webp': 'image/webp',
        '.gif': 'image/gif', '.bmp': 'image/bmp',
    }.get(ext, 'image/jpeg')


class ProductRowWidget(QWidget):
    def __init__(self, text, checked, on_toggle, on_upload, on_clear=None, on_seo=None, on_pipeline=None, on_content=None, on_smart_prep=None, parent=None):
        super().__init__(parent)
        self.setLayoutDirection(Qt.LeftToRight)
        self._on_upload = on_upload
        self._on_clear = on_clear
        self._on_pipeline = on_pipeline
        self._on_content = on_content
        self._on_smart_prep = on_smart_prep
        self._on_seo = on_seo
        row = QHBoxLayout(self)
        row.setDirection(QHBoxLayout.LeftToRight)
        row.setContentsMargins(6, 2, 6, 2)
        row.setSpacing(6)

        self.upload_button = QPushButton("آپلود تصاویر")
        self.upload_button.setLayoutDirection(Qt.LeftToRight)
        self.upload_button.setStyleSheet("padding: 2px 6px; font-size: 11px; min-height: 28px;")
        self.upload_button.setFixedWidth(148)
        self.upload_button.setFixedHeight(36)
        self.upload_button.clicked.connect(self._on_upload)
        row.addWidget(self.upload_button)

        self.seo_button = QToolButton()
        self.seo_button.setText("📝")
        self.seo_button.setToolTip("امتیاز سئو + رفع موارد ناقص این محصول")
        self.seo_button.setFixedSize(28, 28)
        self.seo_button.setCursor(Qt.PointingHandCursor)
        self.seo_button.setStyleSheet(
            "QToolButton { border: 1px solid #fde68a; border-radius: 4px; background: #fffbeb; }"
            "QToolButton:hover { background: #fef3c7; }"
        )
        self.seo_button.clicked.connect(self._handle_seo)
        row.addWidget(self.seo_button)

        self.pipeline_button = QToolButton()
        self.pipeline_button.setText("🎨")
        self.pipeline_button.setToolTip("اجرای روش پردازش تصویر Smart Publish روی تصویر این محصول")
        self.pipeline_button.setFixedSize(28, 28)
        self.pipeline_button.setCursor(Qt.PointingHandCursor)
        self.pipeline_button.setStyleSheet(
            "QToolButton { border: 1px solid #ddd6fe; border-radius: 4px; background: #f5f3ff; }"
            "QToolButton:hover { background: #ede9fe; }"
        )
        self.pipeline_button.clicked.connect(self._handle_pipeline)
        row.addWidget(self.pipeline_button)

        self.content_button = QToolButton()
        self.content_button.setText("📢")
        self.content_button.setToolTip("تولید متن/بنر تبلیغاتی این محصول (AI Content Studio)")
        self.content_button.setFixedSize(28, 28)
        self.content_button.setCursor(Qt.PointingHandCursor)
        self.content_button.setStyleSheet(
            "QToolButton { border: 1px solid #bbf7d0; border-radius: 4px; background: #f0fdf4; }"
            "QToolButton:hover { background: #dcfce7; }"
        )
        self.content_button.clicked.connect(self._handle_content)
        row.addWidget(self.content_button)

        self.smart_prep_button = QToolButton()
        self.smart_prep_button.setText("🤖")
        self.smart_prep_button.setToolTip("آماده‌سازی هوشمند محصول با یک کلیک (سئو ناقص را خودش پیدا و رفع می‌کند)")
        self.smart_prep_button.setFixedSize(28, 28)
        self.smart_prep_button.setCursor(Qt.PointingHandCursor)
        self.smart_prep_button.setStyleSheet(
            "QToolButton { border: 1px solid #93c5fd; border-radius: 4px; background: #eff6ff; }"
            "QToolButton:hover { background: #dbeafe; }"
        )
        self.smart_prep_button.clicked.connect(self._handle_smart_prep)
        row.addWidget(self.smart_prep_button)

        self.clear_button = QToolButton()
        self.clear_button.setText("✕")
        self.clear_button.setToolTip("حذف تصاویر دستی این محصول")
        self.clear_button.setFixedSize(24, 24)
        self.clear_button.setCursor(Qt.PointingHandCursor)
        self.clear_button.setStyleSheet(
            "QToolButton { color: #b91c1c; font-weight: bold; font-size: 13px; "
            "border: 1px solid #fecaca; border-radius: 4px; background: #fff1f2; }"
            "QToolButton:hover { background: #fee2e2; }"
        )
        self.clear_button.clicked.connect(self._handle_clear)
        self.clear_button.hide()
        row.addWidget(self.clear_button)

        row.addStretch(1)

        self.title = QLabel(text)
        self.title.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.title.setWordWrap(False)
        row.addWidget(self.title)

        self.checkbox = QCheckBox()
        self.checkbox.setLayoutDirection(Qt.RightToLeft)
        self.checkbox.setChecked(bool(checked))
        self.checkbox.toggled.connect(on_toggle)
        row.addWidget(self.checkbox)

    def _handle_clear(self):
        if callable(self._on_clear):
            self._on_clear()

    def _handle_seo(self):
        if callable(self._on_seo):
            self._on_seo()

    def _handle_pipeline(self):
        if callable(self._on_pipeline):
            self._on_pipeline()

    def _handle_content(self):
        if callable(self._on_content):
            self._on_content()

    def _handle_smart_prep(self):
        if callable(self._on_smart_prep):
            self._on_smart_prep()

    def set_manual_upload_count(self, count):
        """تعداد تصاویر دستی — ✔ سبز و دکمه حذف."""
        n = int(count or 0)
        self.clear_button.setVisible(n > 0)
        if n > 0:
            self.upload_button.setText(f"آپلود تصاویر ({n}) ✔")
            self.upload_button.setStyleSheet(
                "background-color: #166534; color: white; "
                "padding: 2px 6px; font-size: 11px; min-height: 28px;"
            )
        else:
            self.upload_button.setText("آپلود تصاویر")
            self.upload_button.setStyleSheet(
                "padding: 2px 6px; font-size: 11px; min-height: 28px;"
            )

    def set_upload_count(self, count):
        """سازگاری قدیمی — همان manual count."""
        self.set_manual_upload_count(count)


class ProductTab(QWidget):
    def __init__(self):
        super().__init__()
        self.setLayoutDirection(Qt.RightToLeft)
        self.config = load_secure_config(None)
        self._loading_products = False
        self._image_url_cache = {}
        self._image_pixmap_cache = {}
        self._wc_api = None
        self._current_hover_item = None
        self._uploaded_images_map = self._load_uploaded_images_map()
        self._initial_load_started = False
        self._products_load_generation = 0
        self._refresh_button_default_text = "🔄 بروزرسانی"
        self._sync_button_idle_text = "📤 ارسال محصولات"
        self._upload_images_idle_text = "📷 انتقال تصاویر"
        self._upload_images_idle_style = (
            "QPushButton { background-color: #1a6b2e; color: white; border-radius: 6px; font-weight: bold; }"
            "QPushButton:hover { background-color: #228B3A; }"
            "QPushButton:disabled { background-color: #666; }"
        )
        self._upload_images_stop_style = (
            "QPushButton { background-color: #b45309; color: white; border-radius: 6px; font-weight: bold; }"
            "QPushButton:hover { background-color: #d97706; }"
        )
        self._sync_stop_style = (
            "QPushButton { background-color: #b91c1c; color: #ffffff; font-weight: bold; border-radius: 6px; }"
            "QPushButton:hover { background-color: #991b1b; }"
        )
        self.init_ui()

        self.log_timer = QTimer(self)
        self.log_timer.timeout.connect(self.refresh_logs)
        self.log_timer.start(2000)

        self._sync_started_at = 0.0
        self._sync_live_timer = QTimer(self)
        self._sync_live_timer.setInterval(400)
        self._sync_live_timer.timeout.connect(self._tick_products_sync_ui)

    def _tick_products_sync_ui(self):
        """آپدیت زنده‌ی درصد پیشرفت — با خواندن همون خط لاگ «محصول X/Y» که خودِ اسکریپت سینک می‌نویسه."""
        import re
        import time as _time

        elapsed = int(_time.monotonic() - self._sync_started_at)
        try:
            log_path = app_path("sync.log")
            step = ""
            if os.path.exists(log_path):
                with open(log_path, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                for line in reversed(lines[-60:]):
                    if "محصول" in line and "/" in line:
                        if " - INFO - " in line:
                            part = line.split(" - INFO - ", 1)[-1].strip()
                        else:
                            part = line.strip()
                        if "SyncApp - " in part:
                            part = part.split("SyncApp - ", 1)[-1].strip()
                        step = part
                        break
            m = re.search(r"محصول\s+(\d+)\s*/\s*(\d+)", step)
            if m:
                current, total = int(m.group(1)), max(1, int(m.group(2)))
                pct = min(99, int((current / total) * 100))
                self.sync_progress.setValue(pct)
                self.sync_detail_label.setText(f"{step} — {elapsed} ثانیه")
                self._set_products_status("loading", f"⏳ {step}")
            else:
                self._set_products_status("loading", f"⏳ در حال ارسال محصولات... ({elapsed} ثانیه)")
        except Exception:
            pass

    def init_ui(self):
        main_layout = QHBoxLayout()
        main_layout.setDirection(QHBoxLayout.LeftToRight)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(8)

        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setLayoutDirection(Qt.LeftToRight)
        self.splitter.setHandleWidth(6)

        # پنل لاگ در سمت چپ - با استایل تیره مثل ترمینال
        self.log_view = QTextEdit()
        self.log_view.setObjectName("log_view")
        self.log_view.setReadOnly(True)
        self.log_view.setLayoutDirection(Qt.LeftToRight)
        self.log_view.setMinimumWidth(260)
        self.splitter.addWidget(self.log_view)

        right_panel = QWidget()
        layout = QVBoxLayout(right_panel)

        self.log_actions = LogActionRail(clear_text="حذف لاگ‌های تب محصولات", parent=self)

        self.status_label = QLabel("✓ آماده — برای بارگذاری دکمه بروزرسانی را بزنید")
        self._set_products_status("ready", self.status_label.text())
        layout.addWidget(self.status_label)

        self.load_progress = QProgressBar()
        self.load_progress.setRange(0, 0)
        self.load_progress.setTextVisible(False)
        self.load_progress.setFixedHeight(8)
        self.load_progress.setVisible(False)
        layout.addWidget(self.load_progress)

        self.sync_progress = QProgressBar()
        self.sync_progress.setRange(0, 100)
        self.sync_progress.setValue(0)
        self.sync_progress.setFormat("%p% — ارسال محصولات")
        self.sync_progress.setTextVisible(True)
        self.sync_progress.setFixedHeight(22)
        self.sync_progress.setVisible(False)
        layout.addWidget(self.sync_progress)

        self.sync_detail_label = QLabel("")
        self.sync_detail_label.setWordWrap(True)
        self.sync_detail_label.setStyleSheet("color:#475569; font-size:11px;")
        self.sync_detail_label.setVisible(False)
        layout.addWidget(self.sync_detail_label)

        self.price_label = QLabel("")
        self.price_label.setStyleSheet("font-weight: bold;")
        layout.addWidget(self.price_label)

        layout.addWidget(QLabel("📋 محصولات مرتبط با گروه‌های انتخاب‌شده:"))

        # ── جستجو + فیلتر وضعیت لینک + انتخاب همه/هیچ ────────────────────
        product_search_row = QHBoxLayout()
        product_search_row.setSpacing(8)
        self.product_search = QLineEdit()
        self.product_search.setPlaceholderText("🔍 جستجو در محصولات (نام، کد، قیمت)...")
        self.product_search.setLayoutDirection(Qt.RightToLeft)
        self.product_search.setMinimumHeight(36)
        self.product_search.textChanged.connect(self._filter_products)
        product_search_row.addWidget(self.product_search, 1)

        self.product_link_filter = QComboBox()
        self.product_link_filter.addItem("همه محصولات", "all")
        self.product_link_filter.addItem("✅ فقط لینک‌شده به ووکامرس", "linked")
        self.product_link_filter.addItem("⭕ فقط لینک‌نشده", "unlinked")
        self.product_link_filter.setMinimumHeight(36)
        self.product_link_filter.currentIndexChanged.connect(
            lambda _=0: self._filter_products(self.product_search.text())
        )
        product_search_row.addWidget(self.product_link_filter)

        self._product_selection_toggle = attach_selection_toggle(
            product_search_row,
            self,
            on_select_all=lambda: self._set_all_products_checked(True),
            on_select_none=lambda: self._set_all_products_checked(False),
        )
        layout.addLayout(product_search_row)

        self.product_list = QListWidget()
        self.product_list.setLayoutDirection(Qt.RightToLeft)
        self.product_list.setMouseTracking(True)
        self.product_list.itemEntered.connect(self.on_product_hover)
        self.product_list.viewport().installEventFilter(self)
        layout.addWidget(self.product_list)

        self.image_preview = QLabel(None)
        self.image_preview.setWindowFlags(Qt.ToolTip)
        self.image_preview.setAlignment(Qt.AlignCenter)
        self.image_preview.setStyleSheet(
            "background: #ffffff; border: 1px solid #cbd5e1; border-radius: 10px;"
            "padding: 4px;"
        )
        self.image_preview.setVisible(False)

        self.refresh_button = CompactCaptionButton(self._refresh_button_default_text)
        self.refresh_button.setToolTip("بروزرسانی لیست محصولات از SQL")
        self.refresh_button.clicked.connect(self._on_refresh_clicked)

        self.sync_button = CompactCaptionButton(self._sync_button_idle_text)
        self.sync_button.setToolTip("ارسال محصولات انتخاب‌شده به ووکامرس")
        self.sync_button.clicked.connect(self._on_sync_clicked)

        self.upload_images_button = CompactCaptionButton(self._upload_images_idle_text)
        self.upload_images_button.setProperty("compactActionRole", "images")
        self.upload_images_button.setToolTip("انتقال تصاویر محصولات انتخابی به ووکامرس")
        self.upload_images_button.clicked.connect(self._on_upload_images_clicked)

        self.wc_admin_button = make_wc_admin_open_button(
            self, "products", button_factory=CompactCaptionButton
        )

        self._action_ops = TabActionController(self)
        self._action_ops.register(
            "refresh",
            ActionSpec(
                button=self.refresh_button,
                idle_text=self._refresh_button_default_text,
                stop_text="⏹ توقف بارگذاری",
                on_stop=self._stop_products_load,
            ),
        )
        self._action_ops.register(
            "sync",
            ActionSpec(
                button=self.sync_button,
                idle_text=self._sync_button_idle_text,
                stop_text="⏹ توقف ارسال محصولات",
                stop_style=self._sync_stop_style,
                on_stop=self._stop_products_sync,
            ),
        )
        self._action_ops.register(
            "images",
            ActionSpec(
                button=self.upload_images_button,
                idle_text=self._upload_images_idle_text,
                stop_text="⏹ توقف ارسال تصاویر",
                idle_style=self._upload_images_idle_style,
                stop_style=self._upload_images_stop_style,
                on_stop=self._stop_product_images_upload,
            ),
        )
        self._action_ops.register_extra_widgets(
            self.product_search,
            self.product_list,
            self._product_selection_toggle,
        )

        layout.addWidget(
            build_responsive_action_row(
                [self.refresh_button, self.sync_button, self.upload_images_button, self.wc_admin_button],
                parent=right_panel,
            )
        )

        self.splitter.addWidget(right_panel)
        self.log_panel_controller = LogPanelController(
            splitter=self.splitter,
            button=self.log_actions.toggle_button,
            open_size=380,
            duration_ms=160,
            log_widget=self.log_view,
            parent=self
        )
        self.log_actions.bind_toggle(self.log_panel_controller.toggle)
        self.log_actions.bind_clear(self.clear_tab_logs)
        self.log_panel_controller.collapse_initial()  # پیش‌فرض: لاگ مخفی — با دکمه‌ی کناری نمایش داده می‌شود

        main_layout.addWidget(self.splitter, 1)
        main_layout.addWidget(self.log_actions)

        self.setLayout(main_layout)
        self.refresh_logs()

    def ensure_tab_data_loaded(self):
        if getattr(self, "_action_ops", None) is None:
            return
        from sync_app.core.tab_operation_guard import consume_pending_sql_reload

        consume_pending_sql_reload(self, lambda: self.load_products(manual=False))

    def _ops_busy(self) -> bool:
        ops = getattr(self, "_action_ops", None)
        return bool(ops and ops.busy)

    def _on_refresh_clicked(self):
        self._action_ops.handle_click(
            "refresh",
            lambda: self.load_products(manual=True),
        )

    def _on_sync_clicked(self):
        self._action_ops.handle_click("sync", self._start_send_products)

    def _set_products_status(self, state, text):
        styles = {
            "ready": ("#dcfce7", "#16a34a"),
            "loading": ("#fef3c7", "#92400e"),
            "success": ("#dcfce7", "#16a34a"),
            "warning": ("#fef3c7", "#92400e"),
            "error": ("#fee2e2", "#b91c1c"),
            "info": ("#dbeafe", "#1d4ed8"),
        }
        bg, fg = styles.get(state, styles["ready"])
        self.status_label.setText(text)
        self.status_label.setStyleSheet(
            f"background-color: {bg}; color: {fg}; padding: 8px 12px; "
            "border-radius: 6px; font-weight: bold; font-size: 12px;"
        )

    def _begin_products_load(self, manual=False):
        self._loading_products = True
        self.load_progress.setVisible(True)
        self._action_ops.begin("refresh", lock_tabs=False)
        self._set_products_status("loading", "⏳ در حال دریافت محصولات از SQL...")
        if manual:
            log.info("🔄 کاربر: بروزرسانی لیست محصولات آغاز شد.")

    def _end_products_load(self):
        self._loading_products = False
        self.load_progress.setVisible(False)
        if self._action_ops.active == "refresh":
            self._action_ops.end()

    def _stop_products_load(self):
        self._products_load_generation += 1
        self._loading_products = False
        self.load_progress.setVisible(False)
        self._set_products_status("warning", "⏹ بارگذاری محصولات متوقف شد.")
        if self._action_ops.active == "refresh":
            self._action_ops.end()

    def _fetch_products_from_sql(self, config, selected_groups):
        price_col = config.get("PRICE_LIST_COLUMN", "Sel_Price")
        conn, _, _ = open_sql_connection(config, timeout=3)
        cursor = conn.cursor()
        like_conditions = " OR ".join(["A_Code LIKE ?" for _ in selected_groups])
        query = f"""
            SELECT A_Code, A_Name, Sel_Price, Sel_Price2, Sel_Price3, Sel_Price4, Sel_Price5,
                   Exist, Picture, PicturePath
            FROM Article
            WHERE {like_conditions}
        """
        cursor.execute(query, [f"{group}%" for group in selected_groups])
        rows = []
        for row in cursor.fetchall():
            rows.append({
                "sku": str(row[0]).strip(),
                "name": str(row[1]).strip(),
                "price": resolve_article_price(row, price_col, price_start_index=2),
                "stock": int(row[7] or 0),
                "picture_blob": bytes(row[8]) if row[8] else b"",
                "picture_path": str(row[9] or "").strip(),
            })
        conn.close()
        return rows

    def load_products(self, manual=False):
        if manual and not ensure_connectivity(self, need_sql=True, need_wc=False):
            return

        self.config = load_secure_config(None)
        self._wc_api = None
        price_idx = self.config.get("PRICE_LIST_INDEX", 0) + 1
        self.price_label.setText(f"💰 قیمت‌ها بر اساس: لیست قیمت شماره {price_idx}")

        selected_groups = [str(g).strip() for g in self.config.get("SELECTED_SUB_GROUPS", []) if str(g).strip()]
        if not selected_groups:
            self.product_list.clear()
            self._add_product_message("⚠️ هیچ گروهی انتخاب نشده است.")
            self._set_products_status(
                "warning",
                "⚠️ هیچ گروهی انتخاب نشده — ابتدا در تب دسته‌بندی‌ها گروه را تیک بزنید.",
            )
            if manual:
                QMessageBox.warning(
                    self,
                    "گروه انتخاب نشده",
                    "هیچ گروهی برای فیلتر محصولات انتخاب نشده است.\n"
                    "لطفاً در تب «دسته‌بندی‌ها» زیرگروه موردنظر را تیک بزنید.",
                )
            return

        if self._loading_products or self._ops_busy():
            self._set_products_status("warning", "⏳ بارگذاری قبلی هنوز در جریان است...")
            if manual:
                QMessageBox.information(
                    self,
                    "در حال بارگذاری",
                    "بارگذاری لیست محصولات هنوز تمام نشده است.\nلطفاً چند ثانیه صبر کنید.",
                )
            return

        self._products_load_generation += 1
        generation = self._products_load_generation
        self.product_list.clear()
        self._add_product_message("⏳ در حال بارگذاری محصولات از SQL...")
        self._begin_products_load(manual=manual)

        def _worker():
            return self._fetch_products_from_sql(self.config, selected_groups)

        def _done(rows):
            if generation != self._products_load_generation:
                return
            self._apply_products_rows(rows, manual=manual)

        def _fail(msg):
            if generation != self._products_load_generation:
                return
            self._products_load_failed(msg, manual=manual)

        run_in_thread(_worker, on_complete=_done, on_error=_fail)

    def _products_load_failed(self, error_msg, manual=False):
        err = format_db_error(Exception(str(error_msg)))
        self._end_products_load()
        self.product_list.clear()
        self._add_product_message(f"❌ خطا: {err[:400]}")
        self._set_products_status("error", f"❌ خطا در بارگذاری محصولات: {err[:120]}")
        log.error(f"❌ خطا در بارگذاری لیست محصولات: {err}")
        if manual:
            QMessageBox.critical(self, "خطای دیتابیس", f"بارگذاری محصولات ناموفق بود:\n{err}")

    def _apply_products_rows(self, rows, manual=False):
        self.product_list.clear()
        disabled_products = set(self.config.get("DISABLED_PRODUCT_SKUS", []))
        is_toman = bool(self.config.get("WC_CURRENCY_IS_TOMAN"))
        row_count = 0
        product_map = load_product_woo_map()

        try:
            for row in rows or []:
                row_count += 1
                sku = row["sku"]
                product_name = row["name"]
                price = row["price"] / (10.0 if is_toman else 1.0)
                picture_blob = row["picture_blob"]
                picture_path = row["picture_path"]
                has_erp_image = bool(picture_blob or picture_path)
                image_url = self._image_url_cache.get(sku, "")
                if has_erp_image:
                    image_status = "ERP"
                elif image_url:
                    image_status = "Woo"
                else:
                    image_status = "تستی"

                is_linked = sku in product_map
                link_status = "✅ لینک" if is_linked else "⭕ لینک‌نشده"

                raw_text = (
                    f"{link_status} | {product_name} | کد: {sku} | قیمت: {price:,.0f} | "
                    f"موجودی: {row['stock']} | تصویر: {image_status}"
                )
                item = QListWidgetItem()
                item.setData(Qt.UserRole, sku)
                item.setData(Qt.UserRole + 1, image_url)
                item.setData(Qt.UserRole + 2, picture_blob)
                item.setData(Qt.UserRole + 3, picture_path)
                item.setData(Qt.UserRole + 4, product_name)
                item.setData(Qt.UserRole + 6, raw_text.lower())
                item.setData(Qt.UserRole + 10, row.get("stock"))
                item.setData(Qt.UserRole + 11, price)
                item.setData(Qt.UserRole + 12, is_linked)

                row_widget = ProductRowWidget(
                    self._rtl_display(raw_text),
                    sku not in disabled_products,
                    on_toggle=lambda checked, s=sku: self._on_product_toggle_by_sku(s, checked),
                    on_upload=lambda _=False, s=sku, it=item: self._upload_images_for_product(s, it),
                    on_clear=lambda s=sku, it=item: self._clear_images_for_product(s, it),
                    on_seo=lambda s=sku, it=item: self._open_seo_dialog(s, it),
                    on_pipeline=lambda s=sku, it=item: self._open_pipeline_dialog(s, it),
                    on_content=lambda s=sku, it=item: self._open_content_studio_dialog(s, it),
                    on_smart_prep=lambda s=sku, it=item: self._run_smart_prep(s, it),
                    parent=self.product_list,
                )
                manual_paths = self._existing_manual_image_paths(sku)
                row_widget.set_manual_upload_count(len(manual_paths))
                item.setData(Qt.UserRole + 7, manual_paths)
                item.setSizeHint(QSize(0, 52))
                self.product_list.addItem(item)
                self.product_list.setItemWidget(item, row_widget)

            if row_count == 0:
                self._add_product_message(
                    "ℹ️ برای گروه‌های انتخاب‌شده محصولی یافت نشد. کد گروه/داده Article را بررسی کنید."
                )
                self._set_products_status(
                    "info",
                    "ℹ️ محصولی برای گروه‌های انتخاب‌شده یافت نشد.",
                )
                log.info("ℹ️ بروزرسانی لیست محصولات: موردی یافت نشد.")
            else:
                groups_text = "، ".join(
                    str(g).strip()
                    for g in self.config.get("SELECTED_SUB_GROUPS", [])
                    if str(g).strip()
                )
                self._set_products_status(
                    "success",
                    f"✅ {row_count} محصول بارگذاری شد (گروه‌ها: {groups_text})",
                )
                log.info(f"✅ بروزرسانی لیست محصولات: {row_count} مورد بارگذاری شد.")
            self._filter_products(self.product_search.text())
            self._end_products_load()
            if manual:
                if row_count == 0:
                    QMessageBox.information(
                        self,
                        "نتیجه بروزرسانی",
                        "برای گروه‌های انتخاب‌شده محصولی در دیتابیس یافت نشد.",
                    )
                else:
                    QMessageBox.information(
                        self,
                        "بروزرسانی موفق",
                        f"{row_count} محصول از SQL بارگذاری شد.",
                    )
        except Exception:
            self._end_products_load()
            raise

    def _rtl_display(self, text):
        return f"\u202B{text}\u202C"

    def _add_product_message(self, text):
        item = QListWidgetItem(self._rtl_display(text))
        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.product_list.addItem(item)

    def on_product_toggle(self, item):
        # backward compatibility: in layout جدید از _on_product_toggle_by_sku استفاده می‌شود
        if self._loading_products:
            return

        sku = item.data(Qt.UserRole)
        if not sku:
            return

        cfg = load_secure_config(None) or {}
        disabled_products = set(cfg.get("DISABLED_PRODUCT_SKUS", []))

        if item.checkState() == Qt.Checked:
            disabled_products.discard(sku)
        else:
            disabled_products.add(sku)

        cfg["DISABLED_PRODUCT_SKUS"] = sorted(disabled_products)
        from sync_app.core.secure_config_loader import save_secure_config
        save_secure_config(cfg)

    def _on_product_toggle_by_sku(self, sku, checked):
        if self._loading_products or not sku:
            return

        cfg = load_secure_config(None) or {}
        disabled_products = set(cfg.get("DISABLED_PRODUCT_SKUS", []))
        if checked:
            disabled_products.discard(sku)
        else:
            disabled_products.add(sku)
        cfg["DISABLED_PRODUCT_SKUS"] = sorted(disabled_products)
        from sync_app.core.secure_config_loader import save_secure_config
        save_secure_config(cfg)

    def _images_manifest_path(self):
        return app_path("product_images_map.json")

    def _load_uploaded_images_map(self):
        path = self._images_manifest_path()
        try:
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        return {str(k): list(v) for k, v in data.items() if isinstance(v, list)}
        except Exception:
            pass
        return {}

    def _save_uploaded_images_map(self):
        path = self._images_manifest_path()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self._uploaded_images_map, f, ensure_ascii=False, indent=2)

    def _product_image_abs_path(self, rel_path: str) -> str:
        path = (rel_path or "").strip()
        if not path:
            return ""
        abs_path = path if os.path.isabs(path) else app_path(path)
        return abs_path if os.path.isfile(abs_path) else ""

    def _existing_manual_image_paths(self, sku: str) -> list[str]:
        out = []
        for rel in self._uploaded_images_map.get(sku, []) or []:
            if self._product_image_abs_path(rel):
                out.append(rel)
        return out

    def _erp_image_paths_for_item(self, sku, item) -> list[str]:
        if item is None:
            return []
        blob = item.data(Qt.UserRole + 2) or b""
        picture_path = item.data(Qt.UserRole + 3) or ""
        out = []
        for rel in stage_erp_images(sku, blob, picture_path, self.config or {}):
            if self._product_image_abs_path(rel):
                out.append(rel)
        return out

    def _existing_image_paths_for_product(self, sku, item) -> list[str]:
        """فقط مسیرهایی که فایل روی دیسک دارند — دستی + ERP."""
        paths = list(self._existing_manual_image_paths(sku))
        for rel in self._erp_image_paths_for_item(sku, item):
            if rel not in paths:
                paths.append(rel)
        return paths

    def _prune_stale_manual_images(self, sku, item=None):
        """حذف مسیرهای مرده از نگاشت + به‌روز UI."""
        raw = list(self._uploaded_images_map.get(sku, []) or [])
        valid = self._existing_manual_image_paths(sku)
        if raw == valid:
            return False
        if valid:
            self._uploaded_images_map[sku] = valid
        else:
            self._uploaded_images_map.pop(sku, None)
        self._save_uploaded_images_map()
        if item is not None:
            item.setData(Qt.UserRole + 7, valid)
            row_widget = self.product_list.itemWidget(item)
            if isinstance(row_widget, ProductRowWidget):
                row_widget.set_manual_upload_count(len(valid))
        return True

    def _upload_images_for_product(self, sku, item):
        files, _ = QFileDialog.getOpenFileNames(
            self,
            f"انتخاب تصاویر برای محصول {sku}",
            "",
            "Images (*.png *.jpg *.jpeg *.webp *.bmp)",
        )
        if not files:
            return

        dst_dir = app_path("product_images", sku)
        os.makedirs(dst_dir, exist_ok=True)

        from sync_app.core.smart_publish import (
            AUTO_RUN_KEY, AUTO_PIPELINE_KEY, load_pipelines, load_watermark_settings,
            load_ai_studio_settings, run_pipeline,
        )
        from sync_app.core.media_center import load_image_profiles

        config = load_secure_config(None) or {}
        auto_run = bool(config.get(AUTO_RUN_KEY, False))
        auto_pipeline_name = config.get(AUTO_PIPELINE_KEY)
        pipelines = load_pipelines(config) if auto_run else {}
        auto_pipeline = pipelines.get(auto_pipeline_name) if auto_pipeline_name else None

        rel_paths = list(self._existing_manual_image_paths(sku))
        for src in files:
            base = os.path.basename(src)
            timestamp = str(int(time.time() * 1000))
            dst_name = f"{timestamp}_{base}"
            dst_abs = os.path.join(dst_dir, dst_name)
            try:
                shutil.copy2(src, dst_abs)

                if auto_pipeline:
                    steps = auto_pipeline.get("steps", [])
                    profile_name = auto_pipeline.get("profile", "")
                    profiles = load_image_profiles(config)
                    profile = profiles.get(profile_name) if profile_name else None
                    watermark = load_watermark_settings(config)
                    ai_studio = load_ai_studio_settings(config)
                    result = run_pipeline(
                        dst_abs, steps, out_dir=dst_dir, profile=profile, watermark=watermark,
                        ai_studio=ai_studio,
                    )
                    if result.ok:
                        # فایل نهایی پردازش‌شده جای فایل خام می‌شینه
                        final_ext = os.path.splitext(result.dst_path)[1]
                        final_name = f"{timestamp}_{os.path.splitext(base)[0]}{final_ext}"
                        final_abs = os.path.join(dst_dir, final_name)
                        os.replace(result.dst_path, final_abs)
                        if os.path.isfile(dst_abs) and dst_abs != final_abs:
                            os.remove(dst_abs)
                        dst_name = final_name
                    else:
                        log.warning(f"⚠️ Smart Publish خودکار روی {base} ناموفق بود: {result.error}")

                rel_paths.append(os.path.join("product_images", sku, dst_name).replace("\\", "/"))
            except Exception as exc:
                QMessageBox.warning(self, "خطا", f"کپی تصویر ناموفق بود: {exc}")

        self._uploaded_images_map[sku] = rel_paths
        self._save_uploaded_images_map()
        item.setData(Qt.UserRole + 7, rel_paths)

        row_widget = self.product_list.itemWidget(item)
        if isinstance(row_widget, ProductRowWidget):
            row_widget.set_manual_upload_count(len(rel_paths))

    def _clear_images_for_product(self, sku, item):
        """حذف تصاویر دستی محصول از نگاشت و دیسک."""
        manual = self._existing_manual_image_paths(sku)
        if not manual and not self._uploaded_images_map.get(sku):
            return

        confirm = QMessageBox.question(
            self,
            "حذف تصاویر",
            f"تصاویر دستی محصول {sku} حذف شوند؟\n"
            "(تصاویر ERP و گالری ووکامرس تغییری نمی‌کند.)",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm != QMessageBox.Yes:
            return

        for rel in list(self._uploaded_images_map.get(sku, []) or []):
            abs_path = self._product_image_abs_path(rel)
            if abs_path and os.path.isfile(abs_path):
                try:
                    os.remove(abs_path)
                except Exception as exc:
                    log.warning(f"⚠️ حذف فایل {abs_path}: {exc}")

        self._uploaded_images_map.pop(sku, None)
        self._save_uploaded_images_map()
        item.setData(Qt.UserRole + 7, [])
        row_widget = self.product_list.itemWidget(item)
        if isinstance(row_widget, ProductRowWidget):
            row_widget.set_manual_upload_count(0)
        self.image_preview.hide()

    # ------------------------------------------------------------------
    # سئو: امتیاز واقعی (از روی داده‌ی زنده‌ی سایت) + رفع موارد ناقص
    # ------------------------------------------------------------------
    def _open_seo_dialog(self, sku, item):
        product_map = load_product_woo_map()
        wc_id = product_map.get(sku)
        if not wc_id:
            QMessageBox.information(
                self,
                "ابتدا همگام‌سازی کنید",
                f"محصول {sku} هنوز با ووکامرس همگام نشده — ابتدا سینک کنید.",
            )
            return

        config = load_secure_config(None) or {}
        fallback_name = item.data(Qt.UserRole + 4)

        def _worker():
            apply_network_overrides(config)
            wcapi = build_wcapi(config)
            resp = wcapi.get(
                f"products/{int(wc_id)}",
                params={"_fields": "id,name,short_description,description,categories,images,meta_data"},
            )
            live = resp.json()
            if not isinstance(live, dict) or not live.get("id"):
                raise RuntimeError(f"دریافت اطلاعات زنده‌ی محصول ناموفق بود: {live}")
            return analyze_product_seo_live(live, fallback_name=fallback_name, fallback_desc="")

        def _done(bundle):
            self._show_seo_review_dialog(sku, wc_id, bundle)

        def _fail(msg):
            QMessageBox.critical(self, "خطا", f"دریافت وضعیت سئوی محصول {sku} ناموفق بود:\n{msg}")

        run_in_thread(_worker, on_complete=_done, on_error=_fail)

    def _show_seo_review_dialog(self, sku, wc_id, bundle):
        field_labels = {
            "description": "توضیحات کامل محصول",
            "short_description": "توضیح کوتاه",
            "alt_text": "Alt تصویر",
            "meta_description": "متا دیسکریپشن",
            "seo_title": "عنوان سئو",
            "meta_keywords": "کلمات کلیدی",
        }
        checks = bundle["checks"]
        suggestions = bundle["suggestions"]

        dialog = QDialog(self)
        dialog.setWindowTitle(f"سئوی محصول — {sku}")
        dialog.setLayoutDirection(Qt.RightToLeft)
        dialog.resize(560, 680)
        layout = QVBoxLayout(dialog)

        score_label = QLabel(f"امتیاز فعلی (واقعی، از روی سایت): {bundle['current_score']}/100")
        score_label.setStyleSheet("font-weight:700; font-size:14px;")
        layout.addWidget(score_label)

        status_lines = "\n".join(f"{'✅' if c.ok else '❌'} {c.label}" for c in checks)
        status_label = QLabel(status_lines)
        status_label.setStyleSheet("color:#334155;")
        layout.addWidget(status_label)

        if not bundle["has_image"]:
            warn = QLabel("⚠️ این محصول روی سایت اصلاً تصویر ندارد — Alt تصویر تا وقتی عکسی آپلود نشود قابل ثبت نیست.")
            warn.setWordWrap(True)
            warn.setStyleSheet("color:#b45309;")
            layout.addWidget(warn)

        if not suggestions:
            layout.addWidget(QLabel("✅ همه‌ی موارد سئوی قابل‌بررسی از قبل تکمیل است — چیزی برای پیشنهاد نیست."))
            buttons = QDialogButtonBox(QDialogButtonBox.Close)
            buttons.rejected.connect(dialog.reject)
            buttons.accepted.connect(dialog.accept)
            layout.addWidget(buttons)
            dialog.exec_()
            return

        layout.addWidget(QLabel("موارد ناقص — تیک بزنید تا پیشنهاد ساخته‌شده روی سایت ثبت شود:"))

        checkbox_map = {}
        edit_map = {}
        for field_key, suggested_text in suggestions.items():
            label_text = field_labels.get(field_key, field_key)
            if field_key == "alt_text" and not bundle["has_image"]:
                label_text += " (تصویر ندارد — غیرفعال)"
            if field_key == "description":
                label_text += " — می‌توانید همینجا بنویسید یا از جای دیگر پیست کنید (Ctrl+V)"
            cb = QCheckBox(label_text)
            enabled = field_key != "alt_text" or bundle["has_image"]
            cb.setEnabled(enabled)
            cb.setChecked(enabled)
            layout.addWidget(cb)
            edit = QTextEdit(suggested_text)
            edit.setMaximumHeight(160 if field_key == "description" else 50)
            edit.setPlaceholderText("توضیحات کامل محصول را اینجا بنویسید یا پیست کنید..." if field_key == "description" else "")
            layout.addWidget(edit)
            checkbox_map[field_key] = cb
            edit_map[field_key] = edit

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("📤 ارسال موارد تیک‌خورده به سایت")
        buttons.button(QDialogButtonBox.Cancel).setText("بستن")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        if dialog.exec_() != QDialog.Accepted:
            return

        to_send = {
            key: edit_map[key].toPlainText().strip()
            for key, cb in checkbox_map.items()
            if cb.isChecked() and edit_map[key].toPlainText().strip()
        }
        if not to_send:
            return

        self._send_seo_fixes(sku, wc_id, to_send, bundle.get("image_id"), bundle.get("missing_alt_image_ids"))

    def _send_seo_fixes(self, sku, wc_id, to_send, image_id, extra_image_ids=None):
        config = load_secure_config(None) or {}

        def _worker():
            apply_network_overrides(config)
            wcapi = build_wcapi(config)
            apply_seo_fixes(wcapi, config, wc_id, to_send, image_id, extra_image_ids)
            resp2 = wcapi.get(
                f"products/{int(wc_id)}",
                params={"_fields": "id,name,short_description,description,categories,images,meta_data"},
            )
            live2 = resp2.json()
            new_bundle = analyze_product_seo_live(live2)
            return new_bundle["current_score"]

        def _done(new_score):
            QMessageBox.information(
                self, "ارسال شد",
                f"موارد انتخاب‌شده روی سایت ثبت شد.\nامتیاز جدید (تأییدشده از سایت): {new_score}/100",
            )

        def _fail(msg):
            QMessageBox.critical(self, "خطا", f"ارسال سئوی محصول {sku} ناموفق بود:\n{msg}")

        run_in_thread(_worker, on_complete=_done, on_error=_fail)

    # ------------------------------------------------------------------
    # Smart Publish: اجرای دستی روش پردازش تصویر روی تصویر محصول
    # ------------------------------------------------------------------
    def _open_pipeline_dialog(self, sku, item):
        from sync_app.core.smart_publish import (
            load_pipelines, load_watermark_settings, load_ai_studio_settings, run_pipeline,
        )
        from sync_app.core.media_center import load_image_profiles

        config = load_secure_config(None) or {}
        pipelines = load_pipelines(config)
        if not pipelines:
            QMessageBox.information(
                self, "روش پردازش تصویری تعریف نشده",
                "ابتدا در تب «⚙️ تنظیمات Smart Publish» حداقل یک روش پردازش تصویر بسازید.",
            )
            return

        manual_paths = self._existing_manual_image_paths(sku)
        if manual_paths:
            src = manual_paths[0]
        else:
            src, _ = QFileDialog.getOpenFileName(
                self, f"انتخاب تصویر محصول {sku}", "", "Images (*.jpg *.jpeg *.png *.bmp *.webp)"
            )
            if not src:
                return

        dialog = QDialog(self)
        dialog.setWindowTitle(f"اجرای Smart Publish — {sku}")
        dialog.setLayoutDirection(Qt.RightToLeft)
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel(f"فایل: {os.path.basename(src)}"))
        layout.addWidget(QLabel("روش پردازش تصویر:"))
        combo = QComboBox()
        for name in pipelines:
            combo.addItem(name, name)
        layout.addWidget(combo)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("📤 اجرا و آپلود در سایت")
        buttons.button(QDialogButtonBox.Cancel).setText("انصراف")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        if dialog.exec_() != QDialog.Accepted:
            return

        pipeline_name = combo.currentData()
        pipeline_data = pipelines.get(pipeline_name) or {}
        steps = pipeline_data.get("steps", [])
        profile_name = pipeline_data.get("profile", "")

        product_map = load_product_woo_map()
        wc_id = product_map.get(sku)
        if not wc_id:
            QMessageBox.information(
                self, "ابتدا همگام‌سازی کنید",
                f"محصول {sku} هنوز با ووکامرس همگام نشده — ابتدا سینک کنید.",
            )
            return

        profiles = load_image_profiles(config)
        profile = profiles.get(profile_name) if profile_name else None
        watermark = load_watermark_settings(config)
        ai_studio = load_ai_studio_settings(config)
        out_dir = os.path.dirname(src) or "."

        def _worker():
            result = run_pipeline(
                src, steps, out_dir=out_dir, profile=profile, watermark=watermark,
                ai_studio=ai_studio, webp_quality=85,
            )
            if not result.ok:
                raise RuntimeError(result.error)

            apply_network_overrides(config)
            wcapi = build_wcapi(config)
            resp = wcapi.get(f"products/{int(wc_id)}", params={"_fields": "images"})
            data = resp.json()
            existing_images = data.get("images") or [] if isinstance(data, dict) else []
            new_images = [
                {"id": img.get("id")} for img in existing_images
                if isinstance(img, dict) and img.get("id")
            ]
            with open(result.dst_path, "rb") as f:
                image_bytes = f.read()
            ok, media_id, _url, err = wp_upload_media_ex(
                config, image_bytes, os.path.basename(result.dst_path), fallback_stem=sku
            )
            if not ok:
                raise RuntimeError(f"آپلود رسانه ناموفق بود: {err}")
            new_images.append({"id": media_id})
            ok2, _resp2, err2 = update_wc_product_images(config, wc_id, new_images)
            if not ok2:
                raise RuntimeError(f"افزودن تصویر به گالری محصول ناموفق بود: {err2}")
            return result

        def _done(result):
            QMessageBox.information(
                self, "انجام شد",
                f"روش پردازش تصویر «{pipeline_name}» اجرا شد و به گالری محصول {sku} اضافه شد:\n"
                f"{os.path.basename(result.dst_path)}\n"
                f"حجم قبل: {result.size_before/1024:,.0f}KB → بعد: {result.size_after/1024:,.0f}KB",
            )

        def _fail(msg):
            QMessageBox.critical(self, "خطا", str(msg))

        run_in_thread(_worker, on_complete=_done, on_error=_fail)

    # ------------------------------------------------------------------
    # AI Content Studio: تولید متن/بنر تبلیغاتی برای محصول
    # ------------------------------------------------------------------
    def _open_content_studio_dialog(self, sku, item):
        from sync_app.core.content_studio_helper import (
            generate_instagram_caption, generate_telegram_text, generate_whatsapp_text,
            generate_sms_text, generate_hashtags, create_promo_image,
        )

        product = {
            "name": item.data(Qt.UserRole + 4) or sku,
            "price": item.data(Qt.UserRole + 11) or 0,
            "description": "",
        }

        # لینک کوتاه محصول — فقط اگه این محصول از قبل به ووکامرس لینک شده
        # باشه (چون بدون شناسه‌ی ووکامرس، لینکی برای ساختن نیست). از فرمت
        # کوتاه خودِ وردپرس (?p=ID) استفاده می‌شه، نه یه سرویس کوتاه‌کننده‌ی
        # بیرونی — چون نه وابستگی جدید لازم داره نه اتصال اینترنت اضافه.
        short_link = ""
        try:
            product_map = load_product_woo_map()
            wc_id = product_map.get(sku)
            site_url = str(load_secure_config(None).get("WC_URL") or "").strip().rstrip("/")
            if wc_id and site_url:
                short_link = f"{site_url}/?p={int(wc_id)}"
        except Exception:
            short_link = ""

        dialog = QDialog(self)
        dialog.setWindowTitle(f"AI Content Studio — {sku}")
        dialog.setLayoutDirection(Qt.RightToLeft)
        dialog.resize(560, 620)
        outer = QVBoxLayout(dialog)

        sub_tabs = QTabWidget()
        sub_tabs.setLayoutDirection(Qt.RightToLeft)
        outer.addWidget(sub_tabs)

        # --- زیرتب متن‌ها ---
        text_tab = QWidget()
        text_layout = QVBoxLayout(text_tab)
        texts = {
            "کپشن اینستاگرام": generate_instagram_caption(product),
            "متن تلگرام": generate_telegram_text(product),
            "متن واتساپ": generate_whatsapp_text(product),
            "پیامک تبلیغاتی": generate_sms_text(product),
            "هشتگ‌ها": " ".join(generate_hashtags(product)),
        }
        if short_link:
            for key in ("کپشن اینستاگرام", "متن تلگرام", "متن واتساپ", "پیامک تبلیغاتی"):
                texts[key] = f"{texts[key]}\n\n🔗 {short_link}"
        for label, value in texts.items():
            text_layout.addWidget(QLabel(label + ":"))
            row_h = QHBoxLayout()
            edit = QTextEdit(value)
            edit.setMaximumHeight(70)
            row_h.addWidget(edit)
            copy_btn = QPushButton("📋 کپی")
            copy_btn.setFixedWidth(70)
            copy_btn.clicked.connect(lambda _=False, e=edit: QApplication.clipboard().setText(e.toPlainText()))
            row_h.addWidget(copy_btn)
            text_layout.addLayout(row_h)
        text_layout.addStretch()
        sub_tabs.addTab(text_tab, "📝 متن‌ها")

        # --- زیرتب بنر/پست/استوری ---
        banner_tab = QWidget()
        banner_layout = QVBoxLayout(banner_tab)
        banner_layout.addWidget(QLabel("برای هرکدوم، یه تصویر محصول انتخاب می‌کنید و فایل نهایی ساخته می‌شه:"))

        def _make_banner(kind, *, discount=None, seasonal=None):
            manual_paths = self._existing_manual_image_paths(sku)
            if manual_paths:
                src = manual_paths[0]
            else:
                src, _ = QFileDialog.getOpenFileName(
                    self, f"انتخاب تصویر محصول {sku}", "", "Images (*.jpg *.jpeg *.png *.webp)"
                )
                if not src:
                    return
            out_dir = os.path.dirname(src) or "."
            dst = os.path.join(out_dir, f"{os.path.splitext(os.path.basename(src))[0]}_{kind}.jpg")
            result = create_promo_image(src, product, dst, kind=kind, discount_percent=discount, seasonal_text=seasonal)
            if result.ok:
                QMessageBox.information(self, "ساخته شد", f"فایل ذخیره شد:\n{result.dst_path}")
            else:
                QMessageBox.critical(self, "خطا", f"ساخت تصویر ناموفق بود:\n{result.error}")

        post_btn = QPushButton("🖼️ ساخت پست اینستاگرام (۱۰۸۰×۱۰۸۰)")
        post_btn.clicked.connect(lambda: _make_banner("instagram_post"))
        banner_layout.addWidget(post_btn)

        story_btn = QPushButton("📱 ساخت استوری اینستاگرام (۱۰۸۰×۱۹۲۰)")
        story_btn.clicked.connect(lambda: _make_banner("instagram_story"))
        banner_layout.addWidget(story_btn)

        discount_row = QHBoxLayout()
        discount_spin = QComboBox()
        for pct in (10, 15, 20, 30, 40, 50):
            discount_spin.addItem(f"{pct}٪", pct)
        discount_row.addWidget(QLabel("درصد تخفیف:"))
        discount_row.addWidget(discount_spin)
        discount_btn = QPushButton("🏷️ ساخت بنر تخفیف")
        discount_btn.clicked.connect(lambda: _make_banner("discount_banner", discount=discount_spin.currentData()))
        discount_row.addWidget(discount_btn)
        banner_layout.addLayout(discount_row)

        seasonal_row = QHBoxLayout()
        seasonal_input = QLineEdit()
        seasonal_input.setPlaceholderText("متن مناسبتی (مثلاً «ویژه شب یلدا»)")
        seasonal_row.addWidget(seasonal_input)
        seasonal_btn = QPushButton("🎉 ساخت بنر مناسبتی")
        seasonal_btn.clicked.connect(lambda: _make_banner("seasonal_banner", seasonal=seasonal_input.text().strip() or "پیشنهاد ویژه"))
        seasonal_row.addWidget(seasonal_btn)
        banner_layout.addLayout(seasonal_row)

        banner_layout.addStretch()
        sub_tabs.addTab(banner_tab, "🎨 بنر / پست / استوری")

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(dialog.reject)
        buttons.accepted.connect(dialog.accept)
        outer.addWidget(buttons)

        dialog.exec_()

    # ------------------------------------------------------------------
    # Smart Automation: آماده‌سازی هوشمند محصول با یک کلیک
    # ------------------------------------------------------------------
    def _run_smart_prep(self, sku, item):
        """
        وضعیت واقعی سئوی محصول را از سایت می‌خواند، هر چیزی که ناقص باشد
        (Alt/توضیح کوتاه/متا دیسکریپشن/عنوان سئو/کلمات کلیدی) را با متن
        پیشنهادی قالب‌محور تولید و به‌طور خودکار روی سایت ثبت می‌کند —
        فقط با یک تأیید کلی، نه تیک زدن تک‌تک مثل دکمه‌ی 📝.
        """
        product_map = load_product_woo_map()
        wc_id = product_map.get(sku)
        if not wc_id:
            QMessageBox.information(
                self, "ابتدا همگام‌سازی کنید",
                f"محصول {sku} هنوز با ووکامرس همگام نشده — ابتدا سینک کنید.",
            )
            return

        config = load_secure_config(None) or {}
        fallback_name = item.data(Qt.UserRole + 4)

        def _worker():
            apply_network_overrides(config)
            wcapi = build_wcapi(config)
            resp = wcapi.get(
                f"products/{int(wc_id)}",
                params={"_fields": "id,name,short_description,description,categories,images,meta_data"},
            )
            live = resp.json()
            if not isinstance(live, dict) or not live.get("id"):
                raise RuntimeError(f"دریافت اطلاعات زنده‌ی محصول ناموفق بود: {live}")
            return analyze_product_seo_live(live, fallback_name=fallback_name, fallback_desc="")

        def _done(bundle):
            self._confirm_and_apply_smart_prep(sku, wc_id, bundle)

        def _fail(msg):
            QMessageBox.critical(self, "خطا", f"بررسی وضعیت محصول {sku} ناموفق بود:\n{msg}")

        run_in_thread(_worker, on_complete=_done, on_error=_fail)

    def _confirm_and_apply_smart_prep(self, sku, wc_id, bundle):
        field_labels = {
            "short_description": "توضیح کوتاه",
            "alt_text": "Alt تصویر",
            "meta_description": "متا دیسکریپشن",
            "seo_title": "عنوان سئو",
            "meta_keywords": "کلمات کلیدی",
        }
        suggestions = dict(bundle["suggestions"])
        if not bundle["has_image"]:
            suggestions.pop("alt_text", None)
        # توضیحات بلند رو از آماده‌سازی خودکار حذف می‌کنیم — چون قابل تولید
        # خودکار نیست (باید انسان بنویسه)؛ برای این کار از دکمه‌ی 📝 (سئو)
        # روی همین ردیف استفاده کنید که کادر نوشتن/پیست داره.
        had_description = "description" in suggestions
        suggestions.pop("description", None)

        if not suggestions:
            msg = f"محصول {sku} از نظر سئو کامل است (امتیاز {bundle['current_score']}/100) — چیزی برای رفع نیست."
            if had_description:
                msg += "\n(توضیحات کامل محصول ناقص است، ولی چون قابل تولید خودکار نیست، از دکمه‌ی 📝 سئو برای نوشتن آن استفاده کنید.)"
            QMessageBox.information(self, "همه‌چیز مرتب است", msg)
            return

        field_list = "\n".join(f"• {field_labels.get(k, k)}" for k in suggestions)
        confirm = QMessageBox.question(
            self, "تأیید آماده‌سازی هوشمند",
            f"امتیاز فعلی: {bundle['current_score']}/100\n\n"
            f"این موارد به‌طور خودکار تولید و روی سایت ثبت می‌شوند:\n{field_list}\n\n"
            "ادامه می‌دهید؟",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm != QMessageBox.Yes:
            return

        self._send_seo_fixes(sku, wc_id, suggestions, bundle.get("image_id"))

    def clear_tab_logs(self):
        removed = clear_filtered_logs(["محصول", "products", "sync_fullproduct", "A_Code"])
        self.refresh_logs()
        QMessageBox.information(self, "انجام شد", f"{removed} خط لاگ مربوط به تب محصولات پاک شد.")

    def _start_send_products(self):
        """همگام‌سازی محصولات در پس‌زمینه"""
        self.config = load_secure_config(None) or {}
        if not ensure_connectivity(self, need_sql=True, need_wc=True, live=False):
            return

        # اگه فیلتر (جستجو یا وضعیت لینک) فعاله، آیتم‌های تیک‌خورده‌ای که الان
        # به‌خاطر فیلتر مخفی‌ان نباید ارسال بشن — طبق انتظار کاربر. این کار
        # موقتیه: فقط برای همین یک بار ارسال، ترجیحات واقعی تیک کاربر برای
        # دفعات بعد دست‌نخورده می‌مونه.
        # محافظ مهم: اگه تنظیمات فعلی مشکوک به خالی/ناقص بودن باشه (کمتر از
        # ۵ کلید — یعنی احتمالاً یه خطای لحظه‌ای خواندن بوده، نه تنظیمات واقعی)
        # اصلاً وارد بازی محدودسازی موقت نشو — چون بعداً ذخیره‌ش می‌تونه کل
        # تنظیمات واقعی رو پاک کنه.
        self._temp_extra_disabled = set()
        if isinstance(self.config, dict) and len(self.config) >= 5:
            self._temp_extra_disabled = self._hidden_checked_skus()
            if self._temp_extra_disabled:
                original_disabled = set(self.config.get("DISABLED_PRODUCT_SKUS", []) or [])
                self.config["DISABLED_PRODUCT_SKUS"] = sorted(original_disabled | self._temp_extra_disabled)
                save_secure_config(self.config)

        previews = build_products_sync_preview(self.config)
        if not previews:
            self._restore_temp_disabled_skus()
            QMessageBox.information(
                self,
                "محصولی نیست",
                "محصولی برای ارسال یافت نشد.\n"
                "گروه انتخاب‌شده در دسته‌بندی یا تیک محصولات را بررسی کنید.",
            )
            return
        if not ProductSyncPreviewDialog.ask(self, previews, self.config):
            self._restore_temp_disabled_skus()
            return
        if not confirm_live_site_backup(self, "ارسال محصولات به ووکامرس"):
            self._restore_temp_disabled_skus()
            return

        if not run_background_sync(
            self,
            sync_fullproduct.main,
            on_success=self._products_sync_done,
            on_error=self._products_sync_error,
            need_sql=True,
            need_wc=True,
        ):
            self._restore_temp_disabled_skus()
            thread = getattr(self, "_peecha_bg_sync_thread", None)
            if thread is not None and thread.isRunning():
                QMessageBox.information(self, "در حال اجرا", "همگام‌سازی دیگری در جریان است.")
            return
        self._action_ops.begin("sync")
        self._sync_started_at = time.monotonic()
        self.sync_progress.setValue(2)
        self.sync_progress.setVisible(True)
        self.sync_detail_label.setText("آماده‌سازی ارسال...")
        self.sync_detail_label.setVisible(True)
        self._sync_live_timer.start()
        self._set_products_status("loading", "⏳ در حال ارسال محصولات به ووکامرس...")

    def _hidden_checked_skus(self) -> set:
        """SKUهایی که تیک‌خورده‌ان ولی الان (به‌خاطر فیلتر) روی صفحه مخفی‌ان."""
        hidden_checked = set()
        for i in range(self.product_list.count()):
            item = self.product_list.item(i)
            if not item.isHidden():
                continue
            sku = item.data(Qt.UserRole)
            if not sku:
                continue
            row_widget = self.product_list.itemWidget(item)
            if row_widget is not None and row_widget.checkbox.isChecked():
                hidden_checked.add(sku)
        return hidden_checked

    def _restore_temp_disabled_skus(self):
        """ترجیحات واقعی تیک کاربر رو برمی‌گردونه (بعد از یک ارسال محدودشده‌ی موقت به فیلتر)."""
        extra = getattr(self, "_temp_extra_disabled", None)
        if not extra:
            return
        cfg = load_secure_config(None) or {}
        if not isinstance(cfg, dict) or len(cfg) < 5:
            # تنظیمات مشکوک به خالی/ناقص — دست‌کاریش نکن، امن‌تره
            self._temp_extra_disabled = None
            return
        current_disabled = set(cfg.get("DISABLED_PRODUCT_SKUS", []) or [])
        cfg["DISABLED_PRODUCT_SKUS"] = sorted(current_disabled - extra)
        save_secure_config(cfg)
        self._temp_extra_disabled = None

    def _stop_products_sync(self):
        if self._action_ops.active != "sync":
            return
        if cancel_background_sync(self):
            self._action_ops.set_stopping("sync")
            self._set_products_status("warning", "⏹ در حال توقف ارسال محصولات...")

    def _products_sync_done(self, result=None):
        if self._action_ops.active == "sync":
            self._action_ops.end()
        self._restore_temp_disabled_skus()
        self._sync_live_timer.stop()
        self.sync_progress.setValue(100)
        self.sync_progress.setVisible(False)
        self.sync_detail_label.setVisible(False)
        self.refresh_logs()
        ok_count = (result or {}).get("ok", 0) if isinstance(result, dict) else 0
        if ok_count > 0:
            self._set_products_status("success", f"✅ {ok_count} محصول با موفقیت به ووکامرس ارسال شد.")
            QMessageBox.information(
                self,
                "موفق",
                f"{ok_count} محصول با موفقیت به ووکامرس ارسال شد.",
            )
        else:
            self._set_products_status(
                "info",
                "ℹ️ محصولی برای ارسال یافت نشد — گروه یا تیک محصولات را بررسی کنید.",
            )
            QMessageBox.information(
                self,
                "نتیجه",
                "محصولی برای همگام‌سازی یافت نشد.\n"
                "گروه انتخاب‌شده در دسته‌بندی یا تیک فعال محصولات را بررسی کنید.",
            )

    def _products_sync_error(self, message):
        if self._action_ops.active == "sync":
            self._action_ops.end()
        self._restore_temp_disabled_skus()
        self._sync_live_timer.stop()
        self.sync_progress.setVisible(False)
        self.sync_detail_label.setVisible(False)
        self.refresh_logs()
        if "متوقف" in (message or ""):
            self._set_products_status("info", "⏹ ارسال محصولات متوقف شد.")
            QMessageBox.information(self, "توقف", "ارسال محصولات متوقف شد.")
            return
        short = str(message).split("\n")[0][:160]
        self._set_products_status("error", f"❌ {short}")
        QMessageBox.critical(self, "خطا در همگام‌سازی", str(message))

    # ─── ارسال تصاویر به ووکامرس ──────────────────────────────────────────────

    def _get_wp_base_url(self):
        """استخراج آدرس پایه وردپرس از WC_URL تنظیمات"""
        wc_url = (self.config or {}).get("WC_URL", "").rstrip("/")
        return re.sub(r'/wp-json.*', '', wc_url, flags=re.IGNORECASE) or wc_url

    def _on_upload_images_clicked(self):
        self._action_ops.handle_click("images", self._send_selected_images_to_woo)

    def _end_prod_images_ui(self):
        if self._action_ops.active == "images":
            self._action_ops.end()

    def _stop_product_images_upload(self):
        if self._action_ops.active != "images":
            return
        if cancel_background_sync(self):
            self._action_ops.set_stopping("images")
            self._set_products_status("warning", "⏹ در حال توقف ارسال تصاویر...")
            log.info("⏹ درخواست توقف ارسال تصاویر محصولات ثبت شد.")
        else:
            QMessageBox.information(self, "توقف", "عملیات فعالی برای توقف یافت نشد.")

    def _image_paths_for_product(self, sku, item) -> list[str]:
        """مسیر تصاویر آماده ارسال — فقط فایل‌های موجود."""
        return self._existing_image_paths_for_product(sku, item)

    def _collect_products_for_image_upload(self):
        """محصولات تیک‌خورده با حداقل یک تصویر واقعی."""
        ready = []
        skipped_no_image = []
        pruned = 0

        for i in range(self.product_list.count()):
            item = self.product_list.item(i)
            sku = item.data(Qt.UserRole)
            if not sku:
                continue
            row_widget = self.product_list.itemWidget(item)
            if not isinstance(row_widget, ProductRowWidget):
                continue
            if not row_widget.checkbox.isChecked():
                continue
            if self._prune_stale_manual_images(sku, item):
                pruned += 1
            paths = self._existing_image_paths_for_product(sku, item)
            if paths:
                ready.append((sku, paths))
            else:
                skipped_no_image.append(str(sku))

        return ready, skipped_no_image, pruned

    def _send_selected_images_to_woo(self):
        """ارسال تصاویر محصولات انتخابی به ووکامرس (دستی یا از ERP)"""
        to_process, skipped, pruned = self._collect_products_for_image_upload()
        selected_checked = sum(
            1
            for i in range(self.product_list.count())
            if isinstance(self.product_list.itemWidget(self.product_list.item(i)), ProductRowWidget)
            and self.product_list.itemWidget(self.product_list.item(i)).checkbox.isChecked()
        )

        if not to_process:
            parts = [
                "هیچ محصول تیک‌خورده‌ای با تصویر آماده برای ارسال یافت نشد.",
                "تصویر دستی بگذارید یا Picture/PicturePath در ERP را بررسی کنید.",
            ]
            if skipped:
                parts.append(f"\n{len(skipped)} محصول تیک‌خورده بدون فایل تصویر بود.")
            if pruned:
                parts.append(f"\n{pruned} محصول نگاشت قدیمی بدون فایل پاک‌سازی شد.")
            QMessageBox.information(self, "توجه", "\n".join(parts))
            return

        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("تصاویر موجود در ووکامرس")
        intro = (
            f"از {selected_checked} محصول تیک‌خورده، {len(to_process)} محصول تصویر واقعی دارند.\n\n"
            "اگر محصولی از قبل در ووکامرس تصویر داشته باشد چه کاری انجام شود؟"
        )
        if skipped:
            intro += f"\n\n({len(skipped)} محصول بدون تصویر نادیده گرفته می‌شود)"
        msg_box.setText(intro)
        btn_replace = msg_box.addButton("جایگزین کن", QMessageBox.YesRole)
        msg_box.addButton("به گالری اضافه کن", QMessageBox.NoRole)
        btn_cancel = msg_box.addButton("لغو", QMessageBox.RejectRole)
        msg_box.setDefaultButton(btn_replace)
        msg_box.exec_()

        clicked = msg_box.clickedButton()
        if clicked is btn_cancel:
            return
        replace_mode = (clicked is btn_replace)

        def job():
            self._do_send_images_to_woo(to_process, replace_mode)

        if not run_background_sync(
            self, job,
            on_success=self._images_upload_done,
            on_error=self._images_upload_error,
            need_sql=False,
            need_wc=True,
            wait_on_disconnect=True,
        ):
            thread = getattr(self, "_peecha_bg_sync_thread", None)
            if thread is not None and thread.isRunning():
                QMessageBox.information(self, "در حال اجرا", "یک عملیات دیگر در حال اجرا است.")
            return
        self._action_ops.begin("images")
        self._set_products_status("loading", "⏳ در حال ارسال تصاویر...")

    def _do_send_images_to_woo(self, to_process, replace_mode):
        """اجرا در thread پس‌زمینه — آپلود فایل‌ها به WordPress Media و بروزرسانی محصول"""
        cfg = ensure_wc_sites(load_secure_config(None) or {})
        self._last_img_upload_detail = ""
        timeout = int(cfg.get("WC_TIMEOUT", 60) or 60)

        wp_user, wp_pwd = (cfg.get("WP_USERNAME") or ""), (cfg.get("WP_APP_PASSWORD") or "")
        if wp_user and wp_pwd:
            ok_auth, auth_err = verify_wp_media_credentials(cfg)
            if not ok_auth:
                log.error(f"❌ بررسی Application Password: {auth_err}")
                self._last_img_upload_detail = auth_err
                self._last_img_upload_result = (0, len(to_process))
                return
            log.info("✅ Application Password برای آپلود تصویر تأیید شد.")

        success_count = 0
        fail_count = 0
        log.info(f"📷 شروع ارسال تصاویر {len(to_process)} محصول — فقط فایل‌های موجود روی دیسک")

        for sku, paths in to_process:
            try:
                wait_for_connectivity_blocking(cfg, need_sql=False, need_wc=True)

                while True:
                    wait_for_connectivity_blocking(cfg, need_sql=False, need_wc=True)
                    try:
                        res = wc_rest_request(
                            cfg, "GET", "products", params={"sku": sku}, timeout=timeout
                        ).json()
                    except Exception as exc:
                        if is_transient_connectivity_issue(str(exc)):
                            continue
                        raise
                    break

                if not isinstance(res, list) or not res:
                    log.warning(f"⚠️ محصول {sku} در ووکامرس پیدا نشد — رد شد.")
                    fail_count += 1
                    continue

                p_id = res[0]["id"]
                existing_images = res[0].get("images", [])

                new_images = []
                for rel_or_abs in paths:
                    abs_path = self._product_image_abs_path(rel_or_abs)
                    if not abs_path:
                        log.warning(f"⚠️ فایل تصویر پیدا نشد — {sku}: {rel_or_abs}")
                        continue

                    filename = os.path.basename(abs_path)
                    with open(abs_path, "rb") as f:
                        img_data = f.read()

                    src_url = ""
                    media_id = 0
                    upload_err = ""
                    for attempt in range(1, WP_UPLOAD_MAX_ATTEMPTS + 1):
                        wait_for_connectivity_blocking(cfg, need_sql=False, need_wc=True)
                        ok, media_id, src_url, upload_err = wp_upload_media_ex(
                            cfg,
                            img_data,
                            filename,
                            fallback_stem=f"prod-{sku}",
                            label=sku,
                        )
                        if ok and src_url:
                            log.info(f"✅ تصویر {filename} برای {sku} آپلود شد.")
                            break
                        if is_wp_upload_fatal_error(upload_err) or not should_retry_upload_error(upload_err):
                            break
                        log.warning(
                            f"⚠️ آپلود {filename} — تلاش {attempt}/{WP_UPLOAD_MAX_ATTEMPTS}: {upload_err}"
                        )

                    if not src_url:
                        log.error(f"❌ خطا در آپلود {filename} برای {sku}: {upload_err}")
                        if is_wp_upload_fatal_error(upload_err):
                            self._last_img_upload_detail = upload_err
                        continue

                    if media_id:
                        new_images.append({"id": int(media_id)})
                    else:
                        new_images.append({"src": src_url})

                if not new_images:
                    log.warning(f"⚠️ هیچ تصویری برای {sku} با موفقیت آپلود نشد.")
                    fail_count += 1
                    continue

                if not replace_mode and existing_images:
                    payload_images = list(existing_images) + new_images
                else:
                    payload_images = new_images

                for attempt in range(1, WP_UPLOAD_MAX_ATTEMPTS + 1):
                    wait_for_connectivity_blocking(cfg, need_sql=False, need_wc=True)
                    try:
                        ok_up, _resp, update_err = update_wc_product_images(
                            cfg, p_id, payload_images, timeout=timeout
                        )
                    except Exception as exc:
                        update_err = str(exc)
                        ok_up = False
                        if should_retry_upload_error(update_err) and attempt < WP_UPLOAD_MAX_ATTEMPTS:
                            continue
                        log.error(f"❌ خطا در تنظیم تصویر محصول {sku}: {update_err}")
                        self._last_img_upload_detail = update_err
                        fail_count += 1
                        break

                    if ok_up:
                        log.info(
                            f"✅ {len(new_images)} تصویر برای محصول {sku} (ID:{p_id}) تنظیم شد."
                        )
                        success_count += 1
                        break

                    if should_retry_upload_error(update_err) and attempt < WP_UPLOAD_MAX_ATTEMPTS:
                        log.warning(
                            f"⚠️ تنظیم تصویر {sku} — تلاش {attempt}/{WP_UPLOAD_MAX_ATTEMPTS}: {update_err}"
                        )
                        continue
                    log.error(f"❌ خطا در تنظیم تصویر محصول {sku}: {update_err}")
                    self._last_img_upload_detail = update_err
                    fail_count += 1
                    break

            except Exception as exc:
                from sync_app.core.sync_cancel import SyncCancelled
                if isinstance(exc, SyncCancelled):
                    raise
                log.error(f"❌ خطای کلی در پردازش {sku}: {exc}")
                fail_count += 1

        if fail_count == 0:
            log.info(f"✅ ارسال تصاویر به پایان رسید. {success_count} محصول موفق.")
        else:
            log.warning(
                f"⚠️ ارسال تصاویر تمام شد. موفق: {success_count} | ناموفق: {fail_count}"
            )
        self._last_img_upload_result = (success_count, fail_count)

    def _images_upload_done(self):
        self._end_prod_images_ui()
        self.refresh_logs()
        ok, fail = getattr(self, "_last_img_upload_result", (0, 0))
        if ok > 0 and fail == 0:
            self._set_products_status("success", f"✅ ارسال تصاویر {ok} محصول با موفقیت انجام شد.")
            QMessageBox.information(
                self, "انجام شد",
                f"ارسال تصاویر با موفقیت انجام شد.\n{ok} محصول بروزرسانی شد."
            )
        elif ok > 0 and fail > 0:
            QMessageBox.warning(
                self, "ناقص",
                f"ارسال تمام شد.\nموفق: {ok} | ناموفق: {fail}\nجزئیات در لاگ تب محصولات."
            )
        else:
            detail = getattr(self, "_last_img_upload_detail", "") or ""
            from sync_app.core.wc_site_profiles import ensure_wc_sites
            from sync_app.core.secure_config_loader import load_secure_config
            from sync_app.core.wp_auth_error_ui import show_wp_media_auth_error_if_applicable

            cfg = ensure_wc_sites(load_secure_config(None) or {})
            if show_wp_media_auth_error_if_applicable(
                self,
                detail,
                cfg,
                context="ارسال تصاویر محصولات متوقف شد — مشکل Application Password",
            ):
                return
            extra = f"\n\n{detail}" if detail else ""
            wp_hint = ""
            if not detail or "application password" in detail.lower() or "wp/v2/media" in detail.lower():
                wp_hint = "\n\nتنظیمات: WP Username + Application Password"
            if "products" in detail.lower() and "wc/v3" not in detail.lower():
                wp_hint = "\n\nتنظیم تصویر محصول از API ووکامرس (Consumer Key با Write) انجام می‌شود."
            QMessageBox.critical(
                self,
                "خطا",
                f"ارسال تصاویر ناموفق بود.\nموفق: {ok} | ناموفق: {fail}\n"
                f"جزئیات در لاگ تب محصولات.{wp_hint}{extra}",
            )

    def _images_upload_error(self, message):
        self._end_prod_images_ui()
        self.refresh_logs()
        if "متوقف" in (message or ""):
            self._set_products_status("info", "⏹ ارسال تصاویر متوقف شد.")
            QMessageBox.information(self, "توقف", "ارسال تصاویر محصولات متوقف شد.")
            return
        QMessageBox.critical(self, "خطا", message)

    def get_wc_api(self):
        if self._wc_api is not None:
            return self._wc_api

        if WCAPI is None:
            return None

        cfg = self.config or {}
        url = cfg.get("WC_URL")
        ck = cfg.get("WC_CONSUMER_KEY")
        cs = cfg.get("WC_CONSUMER_SECRET")
        timeout = int(cfg.get("WC_TIMEOUT", 120))
        if not all([url, ck, cs]):
            return None

        self._wc_api = WCAPI(
            url=url,
            consumer_key=ck,
            consumer_secret=cs,
            timeout=timeout,
            version="wc/v3"
        )
        return self._wc_api

    def get_product_image_url(self, sku):
        if sku in self._image_url_cache:
            return self._image_url_cache[sku]

        try:
            wcapi = self.get_wc_api()
            if wcapi is None:
                self._image_url_cache[sku] = ""
                return ""

            res = wcapi.get("products", params={"sku": sku}).json()
            if isinstance(res, list) and res:
                images = res[0].get("images", [])
                if images:
                    image_url = images[0].get("src", "")
                    self._image_url_cache[sku] = image_url
                    return image_url
        except Exception:
            pass

        self._image_url_cache[sku] = ""
        return ""

    def _load_pixmap_from_blob(self, sku, picture_blob):
        if not picture_blob:
            return None

        cache_key = f"erp-blob:{sku}:{len(picture_blob)}"
        cached = self._image_pixmap_cache.get(cache_key)
        if cached is not None:
            return cached

        loaded_pixmap = QPixmap()
        if loaded_pixmap.loadFromData(picture_blob):
            pixmap = loaded_pixmap.scaled(220, 220, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self._image_pixmap_cache[cache_key] = pixmap
            return pixmap
        return None

    def _resolve_local_picture_path(self, picture_path):
        if not picture_path:
            return ""

        normalized = picture_path.strip().strip('"').replace('/', os.sep)
        candidates = [normalized]
        if not os.path.isabs(normalized):
            candidates.append(app_path(normalized))
            candidates.append(os.path.join(os.getcwd(), normalized))

        for candidate in candidates:
            if candidate and os.path.exists(candidate):
                return candidate
        return ""

    def _load_pixmap_from_path_or_url(self, picture_path):
        if not picture_path:
            return None

        cache_key = f"erp-path:{picture_path}"
        cached = self._image_pixmap_cache.get(cache_key)
        if cached is not None:
            return cached

        pixmap = None
        if picture_path.lower().startswith(("http://", "https://")):
            try:
                data = urllib.request.urlopen(picture_path, timeout=3).read()
                loaded_pixmap = QPixmap()
                if loaded_pixmap.loadFromData(data):
                    pixmap = loaded_pixmap.scaled(220, 220, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            except Exception:
                pixmap = None
        else:
            resolved_path = self._resolve_local_picture_path(picture_path)
            if resolved_path:
                loaded_pixmap = QPixmap(resolved_path)
                if not loaded_pixmap.isNull():
                    pixmap = loaded_pixmap.scaled(220, 220, Qt.KeepAspectRatio, Qt.SmoothTransformation)

        if pixmap is not None:
            self._image_pixmap_cache[cache_key] = pixmap
        return pixmap

    def _load_pixmap_from_uploaded_paths(self, sku, paths):
        if not paths:
            return None

        for rel_or_abs in paths:
            abs_path = rel_or_abs
            if not os.path.isabs(abs_path):
                abs_path = app_path(rel_or_abs)
            cache_key = f"uploaded:{sku}:{abs_path}"
            cached = self._image_pixmap_cache.get(cache_key)
            if cached is not None:
                return cached

            if os.path.exists(abs_path):
                loaded = QPixmap(abs_path)
                if not loaded.isNull():
                    pixmap = loaded.scaled(220, 220, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    self._image_pixmap_cache[cache_key] = pixmap
                    return pixmap
        return None

    def _build_placeholder_pixmap(self, sku, product_name):
        cache_key = f"placeholder:{sku}"
        cached = self._image_pixmap_cache.get(cache_key)
        if cached is not None:
            return cached

        pixmap = QPixmap(220, 220)
        pixmap.fill(Qt.transparent)

        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(0, 0, 220, 220, QColor("#f8fafc"))
        painter.setPen(QColor("#cbd5e1"))
        painter.setBrush(QColor("#e2e8f0"))
        painter.drawRoundedRect(8, 8, 204, 204, 18, 18)

        badge_color = QColor("#1a2785")
        painter.setBrush(badge_color)
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(22, 20, 176, 88, 16, 16)

        initial = (product_name or sku or "?").strip()[:1]
        painter.setPen(QColor("#ffffff"))
        painter.setFont(QFont("Segoe UI", 36, QFont.Bold))
        painter.drawText(22, 20, 176, 88, Qt.AlignCenter, initial)

        painter.setPen(QColor("#0f172a"))
        painter.setFont(QFont("Segoe UI", 11, QFont.Bold))
        painter.drawText(18, 126, 184, 30, Qt.AlignCenter, "پیش‌نمایش تستی")

        painter.setPen(QColor("#334155"))
        painter.setFont(QFont("Segoe UI", 9))
        painter.drawText(18, 156, 184, 26, Qt.AlignCenter, sku)
        painter.drawText(18, 182, 184, 24, Qt.AlignCenter, (product_name or "کالا")[:26])
        painter.end()

        self._image_pixmap_cache[cache_key] = pixmap
        return pixmap

    def _resolve_hover_pixmap(self, item):
        sku = item.data(Qt.UserRole) or ""
        picture_blob = item.data(Qt.UserRole + 2) or b""
        picture_path = item.data(Qt.UserRole + 3) or ""
        product_name = item.data(Qt.UserRole + 4) or sku
        uploaded_paths = item.data(Qt.UserRole + 7) or []

        pixmap = self._load_pixmap_from_blob(sku, picture_blob)
        if pixmap is not None:
            return pixmap

        pixmap = self._load_pixmap_from_path_or_url(picture_path)
        if pixmap is not None:
            return pixmap

        pixmap = self._load_pixmap_from_uploaded_paths(sku, uploaded_paths)
        if pixmap is not None:
            return pixmap

        image_url = item.data(Qt.UserRole + 1) or ""
        if not image_url and sku:
            image_url = self.get_product_image_url(sku)
            item.setData(Qt.UserRole + 1, image_url)

        if image_url:
            pixmap = self._load_pixmap_from_path_or_url(image_url)
            if pixmap is not None:
                return pixmap

        return self._build_placeholder_pixmap(sku, product_name)

    def on_product_hover(self, item):
        self._current_hover_item = item
        pixmap = self._resolve_hover_pixmap(item)
        if pixmap is not None:
            self.image_preview.setPixmap(pixmap)
            self.image_preview.resize(pixmap.width() + 10, pixmap.height() + 10)
            self._move_preview_near_cursor()
            self.image_preview.show()
        else:
            self.image_preview.hide()

    def _move_preview_near_cursor(self):
        cursor_pos = QCursor.pos()
        screen = QGuiApplication.screenAt(cursor_pos) or QGuiApplication.primaryScreen()
        available = screen.availableGeometry() if screen else None

        preview_width = self.image_preview.width()
        preview_height = self.image_preview.height()
        left_offset = QPoint(-(preview_width + 22), 12)
        right_offset = QPoint(22, 12)

        preferred_pos = cursor_pos + left_offset
        fallback_pos = cursor_pos + right_offset

        if available is None:
            self.image_preview.move(preferred_pos)
            return

        pos = preferred_pos
        if preferred_pos.x() < available.left():
            pos = fallback_pos

        if pos.x() + preview_width > available.right():
            pos.setX(max(available.left() + 6, available.right() - preview_width - 6))

        if pos.x() < available.left():
            pos.setX(available.left() + 6)

        if pos.y() + preview_height > available.bottom():
            pos.setY(max(available.top() + 6, cursor_pos.y() - preview_height - 12))

        if pos.y() < available.top():
            pos.setY(available.top() + 6)

        self.image_preview.move(pos)

    def eventFilter(self, obj, event):
        if obj is self.product_list.viewport():
            if event.type() == QEvent.Leave:
                self.image_preview.hide()
                self._current_hover_item = None
            elif event.type() == QEvent.MouseMove and self.image_preview.isVisible():
                self._move_preview_near_cursor()
        return super().eventFilter(obj, event)

    def refresh_logs(self):
        try:
            log_path = app_path("sync.log")
            if not os.path.exists(log_path):
                self.log_view.setPlainText("هنوز لاگی ایجاد نشده است.")
                return

            with open(log_path, "r", encoding="utf-8") as f:
                all_lines = f.readlines()

            filtered = [
                line for line in all_lines
                if any(token in line for token in ["محصول", "products", "sync_fullproduct", "A_Code"])
            ]
            self.log_view.setPlainText(format_log_lines_jalali(filtered[-50:]))
            self.log_view.verticalScrollBar().setValue(self.log_view.verticalScrollBar().maximum())
        except Exception as e:
            self.log_view.setPlainText(f"خطا در خواندن لاگ: {e}")

    def _filter_products(self, text):
        """فیلتر لیست محصولات بر اساس متن جستجو + وضعیت لینک ووکامرس"""
        search = text.strip().lower()
        link_mode = self.product_link_filter.currentData() if hasattr(self, "product_link_filter") else "all"
        for i in range(self.product_list.count()):
            item = self.product_list.item(i)
            sku = (item.data(Qt.UserRole) or "").lower()
            item_text = (item.data(Qt.UserRole + 6) or "").lower()
            text_match = not search or search in item_text or search in sku

            is_linked = bool(item.data(Qt.UserRole + 12))
            if link_mode == "linked":
                link_match = is_linked
            elif link_mode == "unlinked":
                link_match = not is_linked
            else:
                link_match = True

            item.setHidden(not (text_match and link_match))

    def _set_all_products_checked(self, checked: bool):
        cfg = load_secure_config(None) or {}
        disabled = set(cfg.get("DISABLED_PRODUCT_SKUS", []) or [])
        for i in range(self.product_list.count()):
            item = self.product_list.item(i)
            sku = item.data(Qt.UserRole)
            if not sku or item.isHidden():
                continue
            row_widget = self.product_list.itemWidget(item)
            if row_widget is None:
                continue
            row_widget.checkbox.setChecked(checked)
            if checked:
                disabled.discard(sku)
            else:
                disabled.add(sku)
        cfg["DISABLED_PRODUCT_SKUS"] = sorted(disabled)
        from sync_app.core.secure_config_loader import save_secure_config
        save_secure_config(cfg)
        self.config = cfg
